<?php
declare(strict_types=1);

// --------------------
// Bootstrap .env
// --------------------
$projectRoot = realpath(__DIR__ . '/..'); // adjust if needed
$autoload = $projectRoot . '/vendor/autoload.php';
if (!file_exists($autoload)) {
    fwrite(STDERR, "Cannot find vendor/autoload.php at: {$autoload}\n");
    exit(2);
}
require_once $autoload;

// Load .env similar to index.php (safeLoad)
$envFile = realpath($projectRoot . '/../.env');
if ($envFile && file_exists($envFile)) {
    $dotenv = Dotenv\Dotenv::createImmutable(dirname($envFile));
    $dotenv->safeLoad();
}

$baseUrl  = getenv('BASE_URL') ?: 'http://localhost';
$basePath = $_ENV['API_BASE_PATH'] ?? ''; // same key used in index.php
$basePath = trim((string)$basePath);
if ($basePath !== '' && $basePath[0] !== '/') $basePath = '/' . $basePath;
$basePath = rtrim($basePath, '/');

$outDir = __DIR__ . DIRECTORY_SEPARATOR . 'route_test_output_selected';
if (!is_dir($outDir)) mkdir($outDir, 0777, true);

$cookieFile = $outDir . DIRECTORY_SEPARATOR . 'cookies.txt';
@file_put_contents($cookieFile, ''); // reset cookies each run

$bearerToken = getenv('AUTH_BEARER_TOKEN') ?: ''; // optional
// --------------------
// Helpers
// --------------------
function joinUrl(string $baseUrl, string $basePath, string $path): string {
    $baseUrl = rtrim($baseUrl, '/');
    $path = trim($path);
    if ($path === '') $path = '/';
    if ($path[0] !== '/') $path = '/' . $path;
    return $baseUrl . $basePath . $path;
}

function indentText(string $text, int $spaces = 2): string {
    $pad = str_repeat(' ', $spaces);
    $lines = preg_split("/\\r\\n|\\n|\\r/", $text);
    return implode("\n", array_map(fn($l) => $pad . $l, $lines));
}

function prettyBody(string $body): string {
    $trim = trim($body);
    if ($trim === '') return '(empty body)';

    $json = json_decode($trim, true);
    if (json_last_error() === JSON_ERROR_NONE) {
        return json_encode($json, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    }
    return $body;
}

function writeFile(string $path, string $content): void {
    file_put_contents($path, $content);
}

function httpRequest(
    string $name,
    string $method,
    string $path,
    array $expectedStatus,
    array $headers,
    ?string $body,
    ?string $contentType,
    string $baseUrl,
    string $basePath,
    string $cookieFile,
    string $outDir,
    string $bearerToken
): bool {
    $url = joinUrl($baseUrl, $basePath, $path);

    $curlHeaders = [];
    foreach ($headers as $k => $v) $curlHeaders[] = $k . ': ' . $v;
    if ($bearerToken !== '') $curlHeaders[] = 'Authorization: Bearer ' . $bearerToken;
    if ($contentType) $curlHeaders[] = 'Content-Type: ' . $contentType;

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $url,
        CURLOPT_CUSTOMREQUEST  => strtoupper($method),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER         => true,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_COOKIEJAR      => $cookieFile,
        CURLOPT_COOKIEFILE     => $cookieFile,
        CURLOPT_TIMEOUT        => 30,
    ]);

    if (!empty($curlHeaders)) curl_setopt($ch, CURLOPT_HTTPHEADER, $curlHeaders);
    if ($body !== null) curl_setopt($ch, CURLOPT_POSTFIELDS, $body);

    $raw = curl_exec($ch);

    $curlErrNo  = curl_errno($ch);
    $curlErrMsg = curl_error($ch);

    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $hSize  = (int)curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    curl_close($ch);

    $respHeaders = $raw !== false ? substr($raw, 0, $hSize) : '';
    $respBody    = $raw !== false ? substr($raw, $hSize) : '';

    if ($raw === false) {
        $status = -1;
        $respBody = "cURL error ($curlErrNo): $curlErrMsg";
    }

    writeFile($outDir . DIRECTORY_SEPARATOR . "{$name}.status.txt", (string)$status);
    writeFile($outDir . DIRECTORY_SEPARATOR . "{$name}.headers.txt", $respHeaders);
    writeFile($outDir . DIRECTORY_SEPARATOR . "{$name}.body.txt", $respBody);

    $expectedStr = implode(',', $expectedStatus);
    $line = sprintf("%-24s %-6s %-28s => %s (expected: %s)", $name, strtoupper($method), $path, $status, $expectedStr);
    echo $line . PHP_EOL;

    $ok = in_array($status, $expectedStatus, true);
    if ($ok) {
        echo "  PASS\n";
        return true;
    }

    // Print errors (status mismatch)
    echo "  FAIL\n";
    if ($curlErrNo !== 0) {
        echo "  cURL error ($curlErrNo): $curlErrMsg\n";
    }

    echo "  --- Response headers ---\n";
    $hdrPreview = trim($respHeaders) === '' ? '(no headers captured)' : rtrim($respHeaders);
    echo indentText($hdrPreview, 2) . "\n";

    echo "  --- Response body ---\n";
    $pretty = prettyBody($respBody);
    if (strlen($pretty) > 7000) {
        $pretty = "…(trimmed)…\n" . substr($pretty, -7000);
    }
    echo indentText($pretty, 2) . "\n";

    return false;
}

function headerContains(string $headersFile, string $needle): bool {
    $txt = @file_get_contents($headersFile);
    if ($txt === false) return false;
    return stripos($txt, $needle) !== false;
}

// --------------------
// Tests (ONLY your pasted routes)
// --------------------
$tests = [
    // Public
    ['01_welcome',            'GET',  '/',                [200],               [], null, null],

    // Middleware tests
    ['02_test_no_mw',         'GET',  '/test/no-middleware', [200],            [], null, null],
    ['03_test_with_mw',       'GET',  '/test/with-middleware', [200],          [], null, null],
    ['04_test_blocked',       'GET',  '/test/blocked',    [403],               [], null, null],

    // Group middleware routes
    ['05_test_group_route1',  'GET',  '/test/group/route1', [200],            [], null, null],
    ['06_test_group_route2',  'GET',  '/test/group/route2', [200],            [], null, null],

    // Nested group route
    ['07_test_nested_deep',   'GET',  '/test/nested/inner/deep', [200],        [], null, null],

    // Orders
    ['08_orders_create',      'POST', '/orders/create',   [200,400,401,422,500], [], '{"user_id":1,"payment_method":"upi","items":[{"product_id":1,"quantity":1}],"notes":"test"}', 'application/json'],
    ['09_orders_details',     'GET',  '/orders/details?order_id=1', [200,400,401,404,422,500], [], null, null],
    ['10_orders_cancel',      'POST', '/orders/cancel',   [200,400,401,422,500], [], '{"order_id":1,"reason":"test"}', 'application/json'],

    // Products
    ['11_products_list',      'GET',  '/products/list?limit=10', [200,400,401,404,422,500], [], null, null],

    // This one is likely to FAIL with 404 because your route definition is 'products/details' (missing leading "/").
    // Keeping it here helps catch and prove the bug in routing configuration.
    ['12_products_details',   'GET',  '/products/details?product_id=1', [200,400,401,404,422,500], [], null, null],

    ['13_products_create',    'POST', '/products/create', [200,400,401,422,500], [], '{"name":"Test Product","sku":"SKU-TEST-1","price":10,"stock":10,"category":"test"}', 'application/json'],
    ['14_products_update',    'POST', '/products/update', [200,400,401,422,500], [], '{"product_id":1,"name":"Updated Product","price":11,"stock":9}', 'application/json'],
];

echo "Base URL: {$baseUrl}\n";
echo "API_BASE_PATH (.env): " . ($basePath === '' ? '<empty>' : $basePath) . "\n";
echo "Output dir: {$outDir}\n";
echo "------------------------------\n";

$failures = 0;

foreach ($tests as $t) {
    [$name,$method,$path,$expected,$hdrs,$body,$ctype] = $t;

    $ok = httpRequest(
        name: $name,
        method: $method,
        path: $path,
        expectedStatus: $expected,
        headers: $hdrs,
        body: $body,
        contentType: $ctype,
        baseUrl: $baseUrl,
        basePath: $basePath,
        cookieFile: $cookieFile,
        outDir: $outDir,
        bearerToken: $bearerToken
    );

    if (!$ok) $failures++;
}

// Middleware assertions
$mwHdrFile = $outDir . DIRECTORY_SEPARATOR . "03_test_with_mw.headers.txt";
if (!headerContains($mwHdrFile, "X-Test-Before: executed")) {
    echo "Header check FAIL: missing 'X-Test-Before: executed' on /test/with-middleware\n";
    $failures++;
} else {
    echo "Header check PASS: X-Test-Before: executed\n";
}

echo "------------------------------\n";
echo $failures > 0 ? "DONE with FAILURES: {$failures}\n" : "DONE: all checks passed\n";
exit($failures > 0 ? 1 : 0);
